//
//  VisualizerAppDelegate.h
//  PrettyCardVisualizer
//
//  Created by Sam on 12/2/14.
//  Copyright (c) 2014 Sam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VisualizerAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
