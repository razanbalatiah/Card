//
//  VisualizerViewController.m
//  PrettyCardVisualizer
//
//  Created by Sam on 12/2/14.
//  Copyright (c) 2014 Sam. All rights reserved.
//

#import "VisualizerViewController.h"
#import "CardView.h"

@interface VisualizerViewController ()

@end

@implementation VisualizerViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    UITapGestureRecognizer *t = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)];
    
    t.numberOfTapsRequired      = 2;
    t.numberOfTouchesRequired   = 2;
    
    [self.view addGestureRecognizer:t];
    
     ;
    
    CardView *v = (CardView*)self.view;
    
    v.rank = self.rank;
    v.suit = self.suit;
}

-(void) tap
{
    [self.navigationController popViewControllerAnimated:YES];
    
}


@end
