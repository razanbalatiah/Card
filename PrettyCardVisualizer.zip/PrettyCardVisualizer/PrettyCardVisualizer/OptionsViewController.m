//
//  OptionsViewController.m
//  PrettyCardVisualizer
//
//  Created by Sam on 12/7/14.
//  Copyright (c) 2014 Sam. All rights reserved.
//

#import "OptionsViewController.h"

#import "VisualizerViewController.h"
@interface OptionsViewController () <UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *labelRank;
@property (weak, nonatomic) IBOutlet UISlider *sliderRank;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation OptionsViewController

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //NSArray *suits = @[@"♣",@"♠",@"♥",@"♦"];
    NSArray *suits = @[@"Clubs",@"Spades",@"Hearts",@"Diamonds"];

    
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"SimpleTableItem"];
    
    
    cell.textLabel.text =suits[indexPath.row];
    
    return cell;
}
- (IBAction)onSliderChanged:(id)sender
{
    UISlider *s = (UISlider*)sender;
    
    NSString *v = [NSString stringWithFormat:@"%d",(int)s.value ];
    
    self.labelRank.text = v;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if (
        [segue.identifier isEqualToString:@"visualize"]
         )
    {
        VisualizerViewController *c = (VisualizerViewController *)segue.destinationViewController;
        
        int r = (int)self.sliderRank.value;
        
        NSIndexPath *path = [self.tableView indexPathForSelectedRow];

        NSArray *suits = @[@"♣",@"♠",@"♥",@"♦"];
        
        NSString *s = suits[path.row];
        
        c.rank = r;
        c.suit = s;
        
    }

}
@end
