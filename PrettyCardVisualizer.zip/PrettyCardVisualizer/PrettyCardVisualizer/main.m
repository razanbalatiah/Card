//
//  main.m
//  PrettyCardVisualizer
//
//  Created by Sam on 12/2/14.
//  Copyright (c) 2014 Sam. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "VisualizerAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([VisualizerAppDelegate class]));
    }
}
