//
//  ViewController.h
//  Matchismo
//
//  Created by Maurizio Cescon on 07/11/13.
//  Copyright (c) 2013 Maurizio Cescon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CardGameVC : UIViewController

@end
