//
//  PlayingCardDeck.h
//  Matchismo
//
//  Created by Maurizio Cescon on 13/11/13.
//  Copyright (c) 2013 Maurizio Cescon. All rights reserved.
//

#import "Deck.h"

@interface PlayingCardDeck : Deck

@end
