//
//  PlayingCard.h
//  Matchismo
//
//  Created by Maurizio Cescon on 13/11/13.
//  Copyright (c) 2013 Maurizio Cescon. All rights reserved.
//

#import "Card.h"

@interface PlayingCard : Card

@property (strong, nonatomic) NSString *suit;
@property (nonatomic) NSUInteger rank;

+ (NSArray *)validSuits;
+ (NSUInteger)maxRank;

@end
