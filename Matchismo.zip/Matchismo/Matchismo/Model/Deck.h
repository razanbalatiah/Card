//
//  Deck.h
//  Matchismo
//
//  Created by Maurizio Cescon on 10/11/13.
//  Copyright (c) 2013 Maurizio Cescon. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Card.h"

@interface Deck : NSObject

- (void)addCard:(Card *)card atTop:(BOOL)atTop;
- (void)addCard:(Card *)card;

- (Card *)drawRandomCard;

@end
