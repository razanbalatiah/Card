//
//  Card.m
//  Matchismo
//
//  Created by Maurizio Cescon on 10/11/13.
//  Copyright (c) 2013 Maurizio Cescon. All rights reserved.
//

#import "Card.h"

@implementation Card

- (int)match:(NSArray *)otherCards
{
    int score = 0;
    
    for (Card *card in otherCards) {
        if ([card.contents isEqualToString:self.contents])
            score = 1;
        NSLog(@"%@ - %@", self.contents, card.contents);
    }
    
    return score;
}

- (void)turnToMatch
{
    self.matched = YES;
}

- (void)turnToUnchosen
{
    self.chosen = NO;
}

- (NSString *)description
{
    return self.contents;
}

@end
