//
//  main.m
//  Matchismo
//
//  Created by Maurizio Cescon on 07/11/13.
//  Copyright (c) 2013 Maurizio Cescon. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
