//
//  ViewController.m
//  Matchismo
//
//  Created by Maurizio Cescon on 07/11/13.
//  Copyright (c) 2013 Maurizio Cescon. All rights reserved.
//

#import "CardGameVC.h"
#import "PlayingCardDeck.h"
#import "CardMatchingGame.h"

@interface CardGameVC ()
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *cardButtons;
@property (weak, nonatomic) IBOutlet UILabel *scoreLabel;
@property (nonatomic, strong) CardMatchingGame *game;
@property (weak, nonatomic) IBOutlet UISegmentedControl *cardMatchingMode;
@property (weak, nonatomic) IBOutlet UILabel *touchCardButtonDescriptionLabel;
@end

@implementation CardGameVC

- (CardMatchingGame *)game
{
    if (!_game) {
        _game = [[CardMatchingGame alloc] initWithCount:[self.cardButtons count] usingDeck:[self createDeck]];
        _game.cardMatchingMode = self.cardMatchingMode.selectedSegmentIndex + 1;
    }
    return _game;
}

- (Deck *)createDeck
{
    return [[PlayingCardDeck alloc] init];
}

- (IBAction)touchCardButton:(UIButton *)sender
{
    self.cardMatchingMode.enabled = NO;
    NSUInteger cardIndex = [self.cardButtons indexOfObject:sender];
    [self.game chooseCardAtIndex:cardIndex];
    [self updateUI];
}

- (void)updateTouchCardButtonDescriptionLabel
{   
    if (self.game.cardMatchingScore > 0) {
        self.touchCardButtonDescriptionLabel.text = [NSString stringWithFormat:@"Matched %@ for %ld points!",
                                                [[self.game cardsTryMatching] componentsJoinedByString:@","],
                                                (long)self.game.cardMatchingScore];
    } else if (self.game.cardMatchingScore < 0) {
        self.touchCardButtonDescriptionLabel.text = [NSString stringWithFormat:@"%@ don't match! %ld points penalty!",
                                                [[self.game cardsTryMatching] componentsJoinedByString:@","],
                                                (long)self.game.cardMatchingScore];
    } else {
        self.touchCardButtonDescriptionLabel.text = [[self.game cardsTryMatching] componentsJoinedByString:@","];
    }
}

- (void)updateUI
{
    for (UIButton *cardButton in self.cardButtons) {
        NSUInteger cardIndex = [self.cardButtons indexOfObject:cardButton];
        Card *card = [self.game cardAtIndex:cardIndex];
        [cardButton setTitle:[self titleForCard:card] forState:UIControlStateNormal];
        [cardButton setBackgroundImage:[self backgroundImageForCard:card] forState:UIControlStateNormal];
        cardButton.enabled = !card.isMatched;
    }
    self.scoreLabel.text = [NSString stringWithFormat:@"Score: %ld", (long)self.game.score];
    [self updateTouchCardButtonDescriptionLabel];
}

- (NSString *)titleForCard:(Card *)card
{
    return card.isChosen ? card.contents : @"";
}

- (UIImage *)backgroundImageForCard:(Card *)card
{
    return [UIImage imageNamed:card.isChosen ? @"cardfront" : @"cardback"];
}

- (IBAction)changeCardMatchingMode:(UISegmentedControl *)sender
{
    self.game.cardMatchingMode = sender.selectedSegmentIndex + 1;
}

- (IBAction)deal
{
    self.game = nil;
    self.scoreLabel.text = @"Score: 0";
    self.cardMatchingMode.enabled = YES;
    [self updateUI];
}

@end
